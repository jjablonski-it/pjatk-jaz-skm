package pl.pjatk.skmapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkmApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
